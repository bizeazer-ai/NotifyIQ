module.exports=[86748,(e,o,d)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_robots_txt_route_actions_1fknk-o.js.map