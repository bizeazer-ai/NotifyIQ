module.exports=[69404,(e,o,d)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_sitemap_xml_route_actions_0t70alw.js.map