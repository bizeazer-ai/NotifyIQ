module.exports=[12465,(e,o,d)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_icon_svg_route_actions_1n5yv0j.js.map