module.exports=[25904,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_waba_page_actions_1c1l5an.js.map