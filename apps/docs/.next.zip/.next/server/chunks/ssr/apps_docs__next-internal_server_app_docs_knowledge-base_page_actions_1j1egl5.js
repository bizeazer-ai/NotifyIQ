module.exports=[71670,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_knowledge-base_page_actions_1j1egl5.js.map