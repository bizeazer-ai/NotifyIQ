module.exports=[57077,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_terms-and-conditions_page_actions_1z9kl_f.js.map