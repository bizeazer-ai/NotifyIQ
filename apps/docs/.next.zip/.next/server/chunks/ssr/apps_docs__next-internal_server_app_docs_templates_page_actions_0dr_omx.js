module.exports=[85178,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_templates_page_actions_0dr_omx.js.map