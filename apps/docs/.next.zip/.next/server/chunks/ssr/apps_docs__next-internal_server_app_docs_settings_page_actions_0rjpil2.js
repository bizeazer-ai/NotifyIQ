module.exports=[95720,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_settings_page_actions_0rjpil2.js.map