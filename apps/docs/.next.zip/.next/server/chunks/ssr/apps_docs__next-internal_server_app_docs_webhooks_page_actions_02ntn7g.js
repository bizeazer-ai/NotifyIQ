module.exports=[22136,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_webhooks_page_actions_02ntn7g.js.map