module.exports=[85461,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_page_actions_1sbl2tf.js.map