module.exports=[67765,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_campaigns_page_actions_0j9374k.js.map