module.exports=[17061,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_dashboard_page_actions_0rq_23t.js.map