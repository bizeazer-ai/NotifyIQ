module.exports=[797,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_privacy-policy_page_actions_10f6eui.js.map