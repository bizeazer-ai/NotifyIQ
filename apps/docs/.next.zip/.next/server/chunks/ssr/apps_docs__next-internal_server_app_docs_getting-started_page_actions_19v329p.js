module.exports=[94612,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_getting-started_page_actions_19v329p.js.map