module.exports=[32082,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_inbox_page_actions_1i3w83z.js.map