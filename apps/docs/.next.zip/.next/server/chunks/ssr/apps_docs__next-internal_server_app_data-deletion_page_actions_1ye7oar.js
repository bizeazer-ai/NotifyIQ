module.exports=[54189,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_data-deletion_page_actions_1ye7oar.js.map