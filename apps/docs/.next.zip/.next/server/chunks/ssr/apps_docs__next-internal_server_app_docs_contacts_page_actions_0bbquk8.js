module.exports=[33359,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_contacts_page_actions_0bbquk8.js.map