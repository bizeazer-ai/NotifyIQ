module.exports=[25295,(a,b,c)=>{}];

//# sourceMappingURL=apps_docs__next-internal_server_app_docs_auth_page_actions_1qt3s_-.js.map