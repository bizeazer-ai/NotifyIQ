var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0_gf5tb._.js")
R.c("server/chunks/ssr/0abh_next_dist_1rqf03z._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0ia63ir._.js")
R.c("server/chunks/ssr/[root-of-the-server]__00wvio2._.js")
R.c("server/chunks/ssr/0abh_next_dist_client_components_builtin_global-error_1e_kxln.js")
R.c("server/chunks/ssr/apps_docs__next-internal_server_app__global-error_page_actions_08t-l56.js")
R.m(83646)
module.exports=R.m(83646).exports
