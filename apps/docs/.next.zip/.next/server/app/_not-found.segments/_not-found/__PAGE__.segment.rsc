1:"$Sreact.fragment"
2:I[66991,["/_next/static/chunks/3acqmy34k3e5m.js"],""]
3:I[71074,["/_next/static/chunks/3acqmy34k3e5m.js"],"OutletBoundary"]
4:"$Sreact.suspense"
8:I[71074,["/_next/static/chunks/3acqmy34k3e5m.js"],"ViewportBoundary"]
9:I[71074,["/_next/static/chunks/3acqmy34k3e5m.js"],"MetadataBoundary"]
7:X
24:X
24:C
0:{"buildId":"mO8jx6ZyszCt-vif0talT","data":[{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-[70vh] flex items-center justify-center px-4 sm:px-6 lg:px-8 py-16 bg-slate-950 text-slate-100","children":["$","div",null,{"className":"max-w-lg w-full text-center space-y-6","children":[["$","div",null,{"className":"inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20","children":[["$","span",null,{"className":"w-2 h-2 rounded-full bg-rose-500"}],"Error 404 • Resource Not Located"]}],["$","h1",null,{"className":"text-4xl sm:text-5xl font-black text-white tracking-tight","children":"Page Not Found"}],["$","p",null,{"className":"text-sm sm:text-base text-slate-400 leading-relaxed","children":"The page or documentation article you are looking for has been relocated or does not exist. Please check the URL or explore our official guides below."}],["$","div",null,{"className":"pt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-left","children":[["$","$L2",null,{"href":"/docs","className":"p-3.5 rounded-xl border border-slate-800 bg-slate-900/60 hover:bg-slate-900 hover:border-slate-700 transition-colors block","children":[["$","div",null,{"className":"text-xs font-bold text-white flex items-center gap-1.5","children":[["$","span",null,{"children":"📚"}]," Documentation Hub"]}],["$","p",null,{"className":"text-[11px] text-slate-400 mt-1","children":"Browse all 13 verified platform and Meta API guides."}]]}],["$","$L2",null,{"href":"/docs/getting-started","className":"p-3.5 rounded-xl border border-slate-800 bg-slate-900/60 hover:bg-slate-900 hover:border-slate-700 transition-colors block","children":[["$","div",null,{"className":"text-xs font-bold text-white flex items-center gap-1.5","children":[["$","span",null,{"children":"🚀"}]," Getting Started"]}],["$","p",null,{"className":"text-[11px] text-slate-400 mt-1","children":"5-minute setup checklist for WABA onboarding."}]]}],["$","$L2",null,{"href":"/privacy-policy","className":"p-3.5 rounded-xl border border-slate-800 bg-slate-900/60 hover:bg-slate-900 hover:border-slate-700 transition-colors block","children":[["$","div",null,{"className":"text-xs font-bold text-white flex items-center gap-1.5","children":[["$","span",null,{"children":"🛡️"}]," Privacy Policy"]}],["$","p",null,{"className":"text-[11px] text-slate-400 mt-1","children":"DPDP Act 2023 & Meta data compliance terms."}]]}],["$","$L2",null,{"href":"/data-deletion","className":"p-3.5 rounded-xl border border-slate-800 bg-slate-900/60 hover:bg-slate-900 hover:border-slate-700 transition-colors block","children":[["$","div",null,{"className":"text-xs font-bold text-white flex items-center gap-1.5","children":[["$","span",null,{"children":"🗑️"}]," Data Deletion"]}],["$","p",null,{"className":"text-[11px] text-slate-400 mt-1","children":"Meta Platform Terms Section 4.a erasure process."}]]}]]}],["$","div",null,{"className":"pt-4","children":["$","$L2",null,{"href":"/","className":"inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors shadow-lg shadow-emerald-500/20","children":"← Return to Homepage"}]}]]}]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":"$@6","staleTime":"$7","varyParams":null},{"rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L8",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#f8fafc","media":"(prefers-color-scheme: light)"}],["$","meta","3",{"name":"theme-color","content":"#020617","media":"(prefers-color-scheme: dark)"}]]}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Page Not Found (404) | NotifyIQ | NotifyIQ"}],["$","meta","1",{"name":"description","content":"The requested documentation or compliance page could not be located."}],"$La","$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14","$L15","$L16","$L17","$L18","$L19","$L1a","$L1b","$L1c","$L1d","$L1e","$L1f"]}]}]}],"$L20"]}],"isPartial":"$@21","staleTime":"$7","varyParams":null},{"rsc":"$L22","isPartial":"$@23","staleTime":"$7","varyParams":"$24"}],"isUpgradeableISRFallback":false,"a":"$@25","rootVaryParams":null,"needsRuntimeRequest":"$@26"}
27:I[91720,["/_next/static/chunks/3acqmy34k3e5m.js"],"IconMark"]
28:I[99553,["/_next/static/chunks/3acqmy34k3e5m.js"],"default"]
29:I[71884,["/_next/static/chunks/3acqmy34k3e5m.js"],"default"]
5:null
a:["$","meta","2",{"name":"author","content":"Aadi IT Services LLP"}]
b:["$","meta","3",{"name":"keywords","content":"WhatsApp Business API,Meta Cloud API,WABA Automation,WhatsApp Chatbot,Customer Support Inbox,Broadcast Campaigns,NotifyIQ,Aadi IT Services LLP"}]
c:["$","meta","4",{"name":"creator","content":"Aadi IT Services LLP"}]
d:["$","meta","5",{"name":"publisher","content":"Aadi IT Services LLP"}]
e:["$","meta","6",{"name":"robots","content":"index, follow"}]
f:["$","meta","7",{"name":"format-detection","content":"telephone=no, address=no, email=no"}]
10:["$","meta","8",{"property":"og:title","content":"NotifyIQ | Enterprise WhatsApp Automation & Intelligence Platform"}]
11:["$","meta","9",{"property":"og:description","content":"Enterprise WhatsApp Business API (WABA) intelligence, broadcast campaigns, visual flow automation, and AI-driven customer support."}]
12:["$","meta","10",{"property":"og:url","content":"https://docs.notifyiq.com"}]
13:["$","meta","11",{"property":"og:site_name","content":"NotifyIQ"}]
14:["$","meta","12",{"property":"og:locale","content":"en_US"}]
15:["$","meta","13",{"property":"og:type","content":"website"}]
16:["$","meta","14",{"name":"twitter:card","content":"summary_large_image"}]
17:["$","meta","15",{"name":"twitter:title","content":"NotifyIQ | Enterprise WhatsApp Automation & Intelligence Platform"}]
18:["$","meta","16",{"name":"twitter:description","content":"Enterprise WhatsApp Business API (WABA) intelligence, broadcast campaigns, visual flow automation, and AI-driven customer support."}]
19:["$","link","17",{"rel":"shortcut icon","href":"/favicon.ico"}]
1a:["$","link","18",{"rel":"icon","href":"/favicon.ico?favicon.1sn0j28rk91yj.ico","sizes":"32x32","type":"image/x-icon"}]
1b:["$","link","19",{"rel":"icon","href":"/icon.svg","type":"image/svg+xml"}]
1c:["$","link","20",{"rel":"icon","href":"/favicon.svg","type":"image/svg+xml"}]
1d:["$","link","21",{"rel":"icon","href":"/favicon.ico","sizes":"32x32"}]
1e:["$","link","22",{"rel":"apple-touch-icon","href":"/apple-icon.svg","type":"image/svg+xml"}]
1f:["$","$L27","23",{}]
20:["$","meta",null,{"name":"next-size-adjust","content":""}]
22:["$","$1","c",{"children":[null,["$","$L28",null,{"parallelRouterKey":"children","template":["$","$L29",null,{}]}]]}]
26:true
7:300
7:C
25:0
21:"$undefined"
23:"$undefined"
6:"$undefined"
