var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.svg/route.js")
R.c("server/chunks/[root-of-the-server]__10d0rie._.js")
R.c("server/chunks/[root-of-the-server]__1opghp7._.js")
R.c("server/chunks/apps_docs__next-internal_server_app_icon_svg_route_actions_1n5yv0j.js")
R.m(17124)
module.exports=R.m(17124).exports
