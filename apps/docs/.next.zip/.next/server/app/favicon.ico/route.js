var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]__0l8ei7u._.js")
R.c("server/chunks/[root-of-the-server]__1opghp7._.js")
R.c("server/chunks/_0zxuytk._.js")
R.c("server/chunks/apps_docs__next-internal_server_app_favicon_ico_route_actions_0zvey-z.js")
R.m(65175)
module.exports=R.m(65175).exports
