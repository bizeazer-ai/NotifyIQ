var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__1bxysxs._.js")
R.c("server/chunks/[root-of-the-server]__1opghp7._.js")
R.c("server/chunks/_0ul--4s._.js")
R.c("server/chunks/apps_docs__next-internal_server_app_sitemap_xml_route_actions_0t70alw.js")
R.m(18151)
module.exports=R.m(18151).exports
