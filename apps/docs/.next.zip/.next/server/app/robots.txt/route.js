var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__1__5ktm._.js")
R.c("server/chunks/[root-of-the-server]__1opghp7._.js")
R.c("server/chunks/apps_docs__next-internal_server_app_robots_txt_route_actions_1fknk-o.js")
R.m(60798)
module.exports=R.m(60798).exports
