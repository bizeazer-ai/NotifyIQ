globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/mO8jx6ZyszCt-vif0talT/_buildManifest.js",
    "static/mO8jx6ZyszCt-vif0talT/_ssgManifest.js",
    "static/mO8jx6ZyszCt-vif0talT/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2kvu94ez548jy.js",
    "static/chunks/3vv8fpxkgtf1f.js",
    "static/chunks/0oxpu0yufp47q.js",
    "static/chunks/04wl6indzwvqj.js",
    "static/chunks/turbopack-0e4vaxdfkg9fn.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
